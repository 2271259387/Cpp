#include<iostream>
using namespace std;
int cf(int a, int n);
int main(int argc, char const *argv[]) {
	int a, n;
	cin >> a >> n;
	cout << cf(a, n);
	return 0;
}
int cf(int a, int n) {
	if (n == 0)		return 1;
	else if (n == 1)return a;
	else return a*cf(a, (n - 1));
}